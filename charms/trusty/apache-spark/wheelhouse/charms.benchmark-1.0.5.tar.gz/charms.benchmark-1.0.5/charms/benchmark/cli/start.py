#!/usr/bin/env python
from charms.benchmark import Benchmark


def main():
    Benchmark().start()

if __name__ == "__main__":
    main()
