import datetime
from uuid import uuid4

import pytz

from . import models as M


class DB(object):
    def __init__(self, session, settings):
        self.db = self.session = session
        self.env = self.get_env(settings)

    @classmethod
    def from_request(cls, request):
        return cls(request.db, request.registry.settings)

    @classmethod
    def from_settings(cls, settings):
        from sqlalchemy import engine_from_config

        engine = engine_from_config(settings, prefix='sqlalchemy.')
        M.Session.configure(bind=engine)

        return cls(M.Session(), settings)

    def get_env(self, settings):
        env = self.db.query(M.Environment).filter_by(
            uuid=settings['juju.env.uuid']).first()
        if not env:
            env = M.Environment(
                uuid=settings['juju.env.uuid'],
                name=settings['juju.env.name'],
                provider_type=settings['juju.env.providertype'],
                default_series=settings['juju.env.defaultseries'],
                region=settings['juju.env.region'],
            )
            self.db.add(env)
        return env

    def get_environments(self):
        """Return a query of all Environments.

        """
        return self.db.query(M.Environment)

    def get_unit(self, name):
        """Return Unit identified by ``name``.

        :param name: unit name in the form "unit-pts-0"

        """
        return self.db.query(M.Unit) \
            .filter(M.Unit.environment_id == self.env.id) \
            .filter_by(name=name) \
            .first()

    def get_action_unit_profiles(self):
        """Return profile data grouped by Action and Unit.

        Example::

            action.uuid:
                unit.name:
                    - profile_data
                    - profile_data

        """
        action_units = {}

        for env in self.db.query(M.Environment):
            for unit in env.units:
                if not unit.data:
                    continue

                unit_data = unit.data
                if not isinstance(unit_data, list):
                    unit_data = [unit_data]

                for d in unit_data:
                    action_uuid = d.get('action')
                    if not action_uuid:
                        continue

                    action_units.setdefault(
                        action_uuid, {}).setdefault(
                        unit.name, []).append(
                        M.Profile(d['data']))

        return action_units

    def get_profile_data(self, unit_name, action_uuid=None, start=None,
                         stop=None):
        """Return saved profiling data for a unit.

        :param unit_name: unit name in the form "unit-pts-0"

        Optionally filter on `action_uuid`
        Optionally filter on `start` <= timestamp >= `stop`.

        """
        unit = self.get_unit(unit_name)
        if not unit:
            return None

        result = unit.data
        if not isinstance(result, list):
            result = [result]

        if not (action_uuid or start or stop):
            return result

        def match(d):
            if action_uuid and d.get('action') != action_uuid:
                return False
            ts = d.get('timestamp')
            if ts:
                ts = datetime.datetime.strptime(ts, "%Y-%m-%dT%H:%M:%SZ")
                ts = pytz.utc.localize(ts)
            if (start and ts) and (ts < start):
                return False
            if (stop and ts) and (ts > stop):
                return False
            return True

        return [d for d in result if match(d)]

    def set_profile_data(self, key, data):
        """Save profiling data for the unit identified by `key`.

        """
        unit = self.get_unit(key)
        if not unit:
            unit = M.Unit(name=key)
            self.env.units.append(unit)
        unit.data = data

    def get_service(self, name):
        """Return Service named ``name`` in the current environment

        """
        return self.db.query(M.Service) \
            .filter(M.Service.environment_id == self.env.id) \
            .filter_by(name=name) \
            .first()

    def get_services(self):
        """Return all Services in the current environment

        """
        return self.db.query(M.Service) \
            .filter(M.Service.environment_id == self.env.id)

    def get_services_data(self):
        """Return data for all services.

        """
        return {s.name: s.data for s in self.get_services()}

    def get_service_data(self, service):
        """Return data (json) for service.

        """
        svc = self.get_service(service)
        return svc.data if svc else None

    def set_service_data(self, service, data):
        """Save data (json) for service.

        """
        svc = self.get_service(service)
        if not svc:
            svc = M.Service(name=service)
            self.env.services.append(svc)
        svc.data = data

    def get_services_benchmarks(self):
        """Return list of benchmark names, by service.

        Example:

            {
                'pts': ['stream', 'smoke'],
            }

        """
        services = self.get_services_data() or {}
        return {svc: services[svc].get('benchmarks', [])
                for svc in services}

    def is_benchmark_action(self, action):
        """Return True if action is a benchmark (as defined by the charm).

        """
        svc_benchmarks = self.get_services_benchmarks()
        if action.service not in svc_benchmarks:
            return True
        if action.name in svc_benchmarks[action.service]:
            return True
        return False

    def get_benchmarks(self):
        """Return all Actions, grouped by benchmark name.

        """
        benchmarks = {}
        for a in self.get_actions():
            benchmarks.setdefault(a.benchmark_name, []).append(a)
        return benchmarks

    def get_action(self, uuid):
        """Return Action identified by ``uuid``.

        """
        return self.db.query(M.Action).filter_by(uuid=uuid).first()

    def get_actions(self):
        """Return all Actions.

        """
        return self.db.query(M.Action)

    def get_action_data(self, uuid):
        """Return data for an action.

        """
        action = self.get_action(uuid)
        if not action:
            return None
        action.data = action.data or {}
        action.data['graphs'] = {
            g.uuid: g.data for g in action.graphs
        }
        action.data['tags'] = [
            t.name for t in action.tags
        ]
        return action.data

    def update_action_tags(self, action_uuid, tags):
        """Update the list of tags associated with an action.

        """
        action = self.get_action(action_uuid)
        if not action:
            action = M.Action(uuid=action_uuid)
            self.env.actions.append(action)
        action.tags = [M.Tag(name=t) for t in tags]

    def insert_action_graph(self, action_uuid, datapoints, label):
        """Save a new graph and return its uuid.

        """
        action = self.get_action(action_uuid)
        if not action:
            action = M.Action(uuid=action_uuid)
            self.env.actions.append(action)
        graph_uuid = uuid4().hex
        action.graphs.append(M.Graph(
            uuid=graph_uuid,
            label=label,
            data={
                'datapoints': datapoints,
                'label': label,
            }
        ))

        return graph_uuid

    def delete_action_graph(self, action_uuid, graph_uuid):
        """Delete a graph.

        """
        graph = self.db.query(M.Graph).filter_by(uuid=graph_uuid).first()
        if graph:
            self.db.delete(graph)

    def get_comparison(self, uuid):
        """Return action comparison identified by ``uuid``.

        """
        return self.db.query(M.Comparison).filter_by(uuid=uuid).first()

    def get_comparison_data(self, uuid):
        """Return data for an action comparison.

        """
        comparison = self.get_comparison(uuid)
        if not comparison:
            return None
        return {
            'graphs': {
                g.uuid: g.data for g in comparison.graphs
            }
        }

    def insert_comparison_graph(self, comparison_id, datapoints, label):
        """Save a new graph and return its uuid.

        """
        comparison = self.get_comparison(comparison_id)
        if not comparison:
            comparison = M.Comparison(uuid=comparison_id)
            self.db.add(comparison)
        graph_uuid = uuid4().hex
        comparison.graphs.append(M.Graph(
            uuid=graph_uuid,
            label=label,
            data={
                'datapoints': datapoints,
                'label': label,
            }
        ))

        return graph_uuid

    def delete_comparison_graph(self, comparison_id, graph_uuid):
        """Delete a graph.

        """
        graph = self.db.query(M.Graph).filter_by(uuid=graph_uuid).first()
        if graph:
            self.db.delete(graph)

    def export_json(self):
        """Return DB contents as JSON.

        """
        result = {}
        result['environments'] = {
            env.uuid: env.to_dict()
            for env in self.db.query(M.Environment)
        }
        result['comparisons'] = {
            c.uuid: c.to_dict()
            for c in self.db.query(M.Comparison)
        }
        result['version'] = '1.0'
        return result

    def import_json(self, json_data):
        """Import data from json produced by export().

        """
        d = json_data
        for uuid, comparison in d['comparisons'].items():
            if self.get_comparison(uuid):
                continue
            c = M.Comparison(uuid=uuid)
            c.graphs = [
                M.Graph.from_dict(g)
                for g in comparison['graphs'].values()
            ]
            self.db.add(c)

        for uuid, data in d['environments'].items():
            env = self.db.query(M.Environment).filter_by(uuid=uuid).first()
            if not env:
                env = M.Environment(
                    uuid=data['uuid'],
                    name=data['name'],
                    provider_type=data['provider_type'],
                    default_series=data['default_series'])
                self.db.add(env)

            existing_action_uuids = self.db.query(M.Action.uuid).all()
            for a in data['actions'].values():
                if a['uuid'] not in existing_action_uuids:
                    env.actions.append(M.Action.from_dict(a))

            existing_service_names = [s.name for s in env.services]
            for s in data['services'].values():
                if s['name'] not in existing_service_names:
                    env.services.append(
                        M.Service(name=s['name'], data=s['data']))

            existing_unit_names = [u.name for u in env.services]
            for u in data['units'].values():
                if u['name'] not in existing_unit_names:
                    env.units.append(
                        M.Unit(name=u['name'], data=u['data']))
