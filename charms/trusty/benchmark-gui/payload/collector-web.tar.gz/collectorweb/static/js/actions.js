(function( $ ) {
  $.fn.compareActions = function(btnSelector) {
    var $btn = $(btnSelector);
    var $chkBoxes = this;
    var checked = $chkBoxes.filter(':checked').toArray();

    $btn.prop('disabled', checked.length !== 2);
    $chkBoxes.on('click', function() {
      if (this.checked) {
        if (checked.length === 2) {
          checked.pop().checked = false;
        }
        checked.push(this);
      }
      else {
        checked = $chkBoxes.filter(':checked').toArray();
      }

      $btn.prop('disabled', checked.length !== 2);
    });

    $btn.on('click', function() {
      var from = checked[0].value;
      var to = checked[1].value;
      var href = '/actions/compare?from=' + from + '&to=' + to;
      document.location.href = href;
    })

    return this;
  };
}( jQuery ));


$(document).ready(function(){
  $('input[name="compare"]').compareActions('.compare');
  $('.filter.menu .item').tab();
  $('.unit.menu .item').tab();
  $('.ui.sidebar').sidebar('attach events', '.launch.button');
  $('.ui.dropdown').dropdown();
  $('.ui.checkbox').checkbox();
  $('.inbox .item').click(function() {
    var tag = $(this).data('tag');
    var self = $(this);
    $('.benchmark.result .dimmer').addClass('active');
    $.get('/actions/' + tag, function(data) {
      $('.item.active').removeClass('active');
      $('#action-data').html(data);
      self.addClass('active');
      $('.benchmark.result .dimmer').removeClass('active');
    });
  });
  $('.inbox .item').first().click();
  $('.ui.launch.button').click(function() {
    $('.launch.modal').modal('show');
  });
  $('div.launch a.benchmark.label').click(function() {
    var benchmark = $(this).data('benchmark');
    $('div.launch a.benchmark.black').removeClass('black');
    $('div.launch div.detail').hide();
    $('div.launch div.detail[data-benchmark=' + benchmark + ']').show();
    $(this).addClass('black');
    $('.modal').modal('refresh');
  });
});
