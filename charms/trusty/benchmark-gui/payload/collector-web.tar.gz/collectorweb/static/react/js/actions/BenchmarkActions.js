var AppDispatcher = require('../dispatcher/AppDispatcher');
var BenchmarkConstants = require('../constants/BenchmarkConstants');

var BenchmarkActions = {

  refreshAll: function() {
    AppDispatcher.dispatch({
      actionType: BenchmarkConstants.BENCHMARK_REFRESH_ALL
    });
  },

  refreshGraphs: function(uuid) {
    AppDispatcher.dispatch({
      actionType: BenchmarkConstants.BENCHMARK_REFRESH_GRAPHS,
      uuid: uuid
    });
  },

  deleteGraph: function(action_uuid, graph_uuid) {
    AppDispatcher.dispatch({
      actionType: BenchmarkConstants.BENCHMARK_DELETE_GRAPH,
      action_uuid: action_uuid,
      graph_uuid: graph_uuid
    });
  },

  refreshMetrics: function(uuid) {
    AppDispatcher.dispatch({
      actionType: BenchmarkConstants.BENCHMARK_REFRESH_METRICS,
      uuid: uuid
    });
  },

  launchBenchmark: function(data) {
    AppDispatcher.dispatch({
      actionType: BenchmarkConstants.BENCHMARK_LAUNCH,
      data: data
    });
  },

  cancelBenchmark: function(uuid) {
    AppDispatcher.dispatch({
      actionType: BenchmarkConstants.BENCHMARK_CANCEL,
      uuid: uuid
    });
  },

  updateBenchmarkTags: function(action_uuid, tags) {
    AppDispatcher.dispatch({
      actionType: BenchmarkConstants.BENCHMARK_UPDATE_TAGS,
      uuid: action_uuid,
      tags: tags
    });
  }

};

module.exports = BenchmarkActions;
