var React = require('react');
var Router = require('react-router');
var _ = require('underscore');

var App = require('./components/App.react')
var BenchmarkStore = require('./stores/BenchmarkStore');
var BenchmarkDashboard = require('./components/BenchmarkDashboard.react');
var BenchmarkDetail = require('./components/BenchmarkDetail.react');
var BenchmarkCompare = require('./components/BenchmarkCompare.react');
var BenchmarkActions = require('./actions/BenchmarkActions');

var DefaultRoute = Router.DefaultRoute;
var Route = Router.Route;
var RouteHandler = Router.RouteHandler;

var WEB_SOCKET_SWF_LOCATION = "/static/WebSocketMain.swf";
var WEB_SOCKET_DEBUG = true;

var BenchmarkDashboardWrapper = React.createClass({
  render: function() {
    var data = BenchmarkStore.getAll();
    return (
      <BenchmarkDashboard
        actions={_.values(BenchmarkStore.getIndex())}
        action_specs={data.action_specs}
        service_units={data.service_units}
      />
    );
  }
});

var routes = (
  <Route name="app" path="/" handler={App}>
    <Route name="action" path="actions/:uuid" handler={BenchmarkDetail}/>
    <Route name="compare" path="compare" handler={BenchmarkCompare}/>
    <DefaultRoute handler={BenchmarkDashboardWrapper}/>
  </Route>
);

Router.run(routes, function (Handler) {
  React.render(
    <Handler/>,
    document.getElementById('content')
  );
});
