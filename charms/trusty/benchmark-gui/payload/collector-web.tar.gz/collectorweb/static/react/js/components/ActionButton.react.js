var React = require('react');
var BS = require('react-bootstrap');

var ActionButton = React.createClass({
  render: function() {
    return (
      <BS.DropdownButton
        bsStyle="primary"
        title="Take Action"
        className="pull-right btn-launch"
      >
        {this.props.children}
      </BS.DropdownButton>
    );
  }
});


module.exports = ActionButton;
