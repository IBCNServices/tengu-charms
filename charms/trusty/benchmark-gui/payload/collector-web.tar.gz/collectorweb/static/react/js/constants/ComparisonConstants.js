var keyMirror = require('keymirror');

module.exports = keyMirror({
  COMPARISON_REFRESH: null,
  COMPARISON_DELETE_GRAPH: null,
});
