var React = require('react');
var moment = require('moment');
var BenchmarkStore = require('../stores/BenchmarkStore');

var status_color_map = {
  'completed': 'green',
  'cancelled': 'red',
  'failed': 'red',
  'pending': 'yellow',
  'running': 'blue',
  'canceling': 'yellow'
}

var Utils = {

  statusColor: function(status) {
    return status_color_map[status];
  },

  formatResult: function(val) {
    if (val && val.value) {
      return val.value + ' ' + (val.units || '');
    }
    return val;
  },

  timeDeltaHtml: function(strDate) {
    if (!strDate) {
      return null;
    }

    var started = moment(strDate);
    var displayDate;

    if (moment().diff(started, 'days') > 30) {
      displayDate = started.format('YYYY-MM-DD');
    }
    else {
      displayDate = started.fromNow();
    }

    return (
      <span title={strDate.replace("T", " ")}>
        {displayDate}
      </span>
    );
  },

  UnitProfileChooser: React.createClass({
    propTypes: {
      action: React.PropTypes.object.isRequired,
      onChange: React.PropTypes.func
    },

    getInitialState: function() {
      var action = this.props.action;
      var unitProfiles = BenchmarkStore.getActionUnitProfiles(action);
      var units = Object.keys(unitProfiles).sort();
      var selectedUnit = null;

      if (units.indexOf(action.receiver) !== -1) {
        selectedUnit = action.receiver;
      }
      else {
        selectedUnit = units ? units[0] : null;
      }

      if (selectedUnit) {
        this.props.onChange(unitProfiles[selectedUnit][0]);
      }

      return {
        selectedUnit: selectedUnit,
        unitProfiles: unitProfiles
      };
    },

    handleUnitChange: function(event) {
      var unit = event.target.value;
      this.setState({
        selectedUnit: unit
      });
      this.props.onChange(this.state.unitProfiles[unit][0]);
    },

    render: function() {
      var unitProfiles = this.state.unitProfiles;
      var selectedUnit = this.state.selectedUnit;

      if (!Object.keys(unitProfiles).length) {
        return null;
      }

      return (
        <select onChange={this.handleUnitChange} defaultValue={selectedUnit}>
        {Object.keys(unitProfiles).sort().map(function(i) {
          return (
            <option value={i} key={i}>{i}</option>
          );
        })};
        </select>
      );
    }
  })
}

module.exports = Utils;
