Sample configuration files for deploying `collector-web` under apache
mod_wsgi.
