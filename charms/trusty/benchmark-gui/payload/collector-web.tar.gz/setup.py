from setuptools import setup

requires = [
    'alembic',
    'coverage',
    'flake8',
    'gevent-socketio',
    'gevent-websocket',
    'gevent==1.0.2',
    'humanize',
    'jujuclient',
    'mock',
    'nose',
    'psycopg2',
    'pyramid',
    'pyramid_mako',
    'pyramid_debugtoolbar',
    'python-dateutil',
    'pyyaml',
    'pytz',
    'requests',
    'sqlalchemy',
    'waitress',
    ]

setup(name='collectorweb',
      version='1.2.1',
      install_requires=requires,
      url='http://github.com/juju-solutions/collector-web',
      packages=['collectorweb'],
      include_package_data=True,
      zip_safe=False,
      entry_points="""\
      [paste.app_factory]
      main = collectorweb:main
      [console_scripts]
      initialize_db = collectorweb.scripts.initialize_db:main
      """,
      )
